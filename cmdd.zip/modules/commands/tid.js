module.exports.config = {
	name: "ايدي_مج",	
  version: "1.0.0", 
	hasPermssion: 0,
	credits: "𝙈𝙧𝙏𝙤𝙢𝙓𝙭𝙓",
	description: "group id", 
	commandCategory: "group",
	usages: "tid",
	cooldowns: 5, 
	dependencies: '',
};

module.exports.run = async function({ api, event }) {
  api.sendMessage(` ` +event.threadID, event.threadID, event.messageID);
};